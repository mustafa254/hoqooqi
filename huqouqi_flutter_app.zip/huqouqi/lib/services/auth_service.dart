import 'package:firebase_auth/firebase_auth.dart';

/// Thin wrapper around FirebaseAuth for phone-number authentication,
/// which is the standard flow for an Iraqi citizen/lawyer user base.
///
/// Wire-up checklist (see README.md):
/// 1. Enable "Phone" sign-in provider in Firebase Console > Authentication.
/// 2. Add your app's SHA-1/SHA-256 fingerprints (Android) for reCAPTCHA-less flow.
/// 3. Call [sendOtp] then [verifyOtp] from your login screen.
class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  User? get currentUser => _auth.currentUser;

  /// Starts phone verification. [onCodeSent] receives the verificationId
  /// which must be passed to [verifyOtp].
  Future<void> sendOtp({
    required String phoneNumber, // e.g. +9647XXXXXXXXX
    required void Function(String verificationId) onCodeSent,
    required void Function(FirebaseAuthException e) onError,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: onError,
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (String verificationId) {},
    );
  }

  Future<UserCredential> verifyOtp({
    required String verificationId,
    required String smsCode,
  }) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    return _auth.signInWithCredential(credential);
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  /// Deletes the currently signed-in Firebase Auth user.
  /// Pair this with [FirestoreService.deleteUserData] to remove Firestore data.
  Future<void> deleteAccount() async {
    final user = _auth.currentUser;
    if (user != null) {
      await user.delete();
    }
  }
}
