import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/lawyer_model.dart';
import '../models/consultation_model.dart';
import '../models/case_model.dart';
import '../models/user_model.dart';

/// Central Firestore access layer. All screens should go through this
/// service rather than calling FirebaseFirestore.instance directly, so the
/// data layer stays swappable/testable.
///
/// Suggested collections:
///   users/{uid}
///   lawyers/{lawyerId}
///   consultations/{consultationId}  (subcollection: messages/{messageId})
///   cases/{caseId}
///   posts/{postId}                  (public legal inquiries from "طلب استشارة")
///   blocked/{uid}/list/{blockedUid}
class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ---------------- Users ----------------
  Future<void> createOrUpdateUser(UserModel user) async {
    await _db.collection('users').doc(user.uid).set(user.toMap(), SetOptions(merge: true));
  }

  Future<UserModel?> getUser(String uid) async {
    final doc = await _db.collection('users').doc(uid).get();
    if (!doc.exists) return null;
    return UserModel.fromMap(doc.id, doc.data()!);
  }

  Future<void> deleteUserData(String uid) async {
    await _db.collection('users').doc(uid).delete();
    // TODO: also cascade-delete or anonymize user's posts/consultations as needed.
  }

  // ---------------- Lawyers Directory ----------------
  Stream<List<LawyerModel>> streamLawyers({
    String? governorate,
    List<String>? specialties,
  }) {
    Query<Map<String, dynamic>> query = _db.collection('lawyers');
    if (governorate != null && governorate.isNotEmpty) {
      query = query.where('governorate', isEqualTo: governorate);
    }
    if (specialties != null && specialties.isNotEmpty) {
      query = query.where('specialties', arrayContainsAny: specialties);
    }
    return query.snapshots().map(
          (snap) => snap.docs.map((d) => LawyerModel.fromMap(d.id, d.data())).toList(),
        );
  }

  Future<List<LawyerModel>> searchLawyersByName(String query) async {
    // Firestore doesn't support native full-text search; for production,
    // integrate Algolia/Typesense or a Cloud Function-based search index.
    final snap = await _db
        .collection('lawyers')
        .orderBy('name')
        .startAt([query])
        .endAt(['$query\uf8ff'])
        .get();
    return snap.docs.map((d) => LawyerModel.fromMap(d.id, d.data())).toList();
  }

  // ---------------- Consultations / Chat ----------------
  Stream<List<ConsultationModel>> streamConsultations(String uid) {
    return _db
        .collection('users')
        .doc(uid)
        .collection('consultations')
        .orderBy('lastMessageAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => ConsultationModel.fromMap(d.id, d.data())).toList());
  }

  Future<void> sendMessage({
    required String uid,
    required String consultationId,
    required String text,
    required bool fromCitizen,
  }) async {
    final ref = _db
        .collection('users')
        .doc(uid)
        .collection('consultations')
        .doc(consultationId)
        .collection('messages');
    await ref.add({
      'text': text,
      'fromCitizen': fromCitizen,
      'sentAt': FieldValue.serverTimestamp(),
    });
  }

  /// Publishes a public legal inquiry created via the "Request Consultation"
  /// bottom sheet on the Home screen.
  Future<void> publishInquiry({
    required String uid,
    required String authorName,
    required String text,
  }) async {
    await _db.collection('posts').add({
      'uid': uid,
      'authorName': authorName,
      'text': text,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> streamMyPosts(String uid) {
    return _db
        .collection('posts')
        .where('uid', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  // ---------------- My Cases ----------------
  Stream<List<CaseModel>> streamCases(String uid, {required String status}) {
    return _db
        .collection('users')
        .doc(uid)
        .collection('cases')
        .where('status', isEqualTo: status)
        .orderBy('openedAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => CaseModel.fromMap(d.id, d.data())).toList());
  }

  // ---------------- Blocked Users ----------------
  Future<void> blockUser(String uid, String blockedUid) async {
    await _db.collection('users').doc(uid).collection('blocked').doc(blockedUid).set({
      'blockedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> unblockUser(String uid, String blockedUid) async {
    await _db.collection('users').doc(uid).collection('blocked').doc(blockedUid).delete();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> streamBlockedUsers(String uid) {
    return _db.collection('users').doc(uid).collection('blocked').snapshots();
  }
}
