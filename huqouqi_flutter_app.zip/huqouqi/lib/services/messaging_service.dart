import 'package:firebase_messaging/firebase_messaging.dart';

/// Handles push-notification permission requests and token retrieval.
/// Use the FCM token to notify citizens of new chat replies, and lawyers of
/// new inquiries.
class MessagingService {
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;

  Future<void> initialize() async {
    await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
  }

  Future<String?> getToken() => _messaging.getToken();

  /// Call this once after login to persist the token on the user's
  /// Firestore document (e.g. via FirestoreService.createOrUpdateUser).
  Stream<String> get onTokenRefresh => _messaging.onTokenRefresh;

  void listenForForegroundMessages(void Function(RemoteMessage) onMessage) {
    FirebaseMessaging.onMessage.listen(onMessage);
  }
}
