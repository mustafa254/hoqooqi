import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';

/// Handles uploads of profile photos, lawyer license documents, and any
/// case-related attachments to Firebase Storage.
class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<String> uploadProfilePhoto({
    required String uid,
    required File file,
  }) async {
    final ref = _storage.ref().child('profile_photos/$uid.jpg');
    await ref.putFile(file);
    return ref.getDownloadURL();
  }

  Future<String> uploadLawyerLicense({
    required String lawyerId,
    required File file,
  }) async {
    final ref = _storage.ref().child('lawyer_licenses/$lawyerId.pdf');
    await ref.putFile(file);
    return ref.getDownloadURL();
  }

  Future<void> deleteFile(String downloadUrl) async {
    final ref = _storage.refFromURL(downloadUrl);
    await ref.delete();
  }
}
