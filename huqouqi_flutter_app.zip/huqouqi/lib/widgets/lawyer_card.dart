import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/routes.dart';
import '../models/lawyer_model.dart';
import '../theme/app_theme.dart';

/// Card representation of a lawyer inside the Lawyers Directory list.
class LawyerCard extends StatelessWidget {
  final LawyerModel lawyer;

  const LawyerCard({super.key, required this.lawyer});

  Future<void> _call(BuildContext context) async {
    final uri = Uri(scheme: 'tel', path: lawyer.phoneNumber);
    if (!await launchUrl(uri)) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر تشغيل تطبيق الاتصال')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (lawyer.isPromoted)
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.gold.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.star, size: 13, color: AppColors.gold),
                      const SizedBox(width: 4),
                      Text(
                        'محامي مميز',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: isDark ? AppColors.goldLight : AppColors.navy,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Photo
                CircleAvatar(
                  radius: 30,
                  backgroundColor: AppColors.navy.withOpacity(0.1),
                  backgroundImage: lawyer.photoUrl != null ? NetworkImage(lawyer.photoUrl!) : null,
                  child: lawyer.photoUrl == null
                      ? Icon(Icons.person, size: 30, color: AppColors.navy.withOpacity(0.5))
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              lawyer.name,
                              style: Theme.of(context)
                                  .textTheme
                                  .titleSmall
                                  ?.copyWith(fontWeight: FontWeight.w700),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (lawyer.isVerified)
                            const Padding(
                              padding: EdgeInsets.only(right: 4),
                              child: Icon(Icons.verified, size: 16, color: AppColors.verifiedBlue),
                            ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          const Icon(Icons.star, size: 15, color: AppColors.gold),
                          const SizedBox(width: 4),
                          Text(
                            '${lawyer.rating.toStringAsFixed(1)} (${lawyer.reviewsCount})',
                            style: const TextStyle(fontSize: 12.5),
                          ),
                          const SizedBox(width: 10),
                          Icon(Icons.location_on_outlined,
                              size: 15, color: AppColors.textSecondary),
                          const SizedBox(width: 2),
                          Expanded(
                            child: Text(
                              lawyer.governorate,
                              style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: lawyer.specialties.take(3).map((s) {
                          return Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: AppColors.navy.withOpacity(0.06),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(s, style: const TextStyle(fontSize: 11)),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _call(context),
                    icon: const Icon(Icons.call, size: 18),
                    label: const Text('اتصال'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.of(context).pushNamed(
                        AppRoutes.lawyerProfile,
                        arguments: lawyer,
                      );
                    },
                    icon: const Icon(Icons.badge_outlined, size: 18),
                    label: const Text('الملف المهني'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
