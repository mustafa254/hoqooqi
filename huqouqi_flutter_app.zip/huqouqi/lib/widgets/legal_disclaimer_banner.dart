import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../theme/app_theme.dart';

/// Fixed banner communicating that Huqouqi is an informational/directional
/// platform, not a direct legal-advice provider. Shown at the bottom of the
/// Home screen per the product requirement.
class LegalDisclaimerBanner extends StatelessWidget {
  const LegalDisclaimerBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkSurface : AppColors.navy.withOpacity(0.06),
        border: Border(
          top: BorderSide(
            color: isDark ? AppColors.gold.withOpacity(0.4) : AppColors.navy.withOpacity(0.15),
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.info_outline,
            size: 18,
            color: isDark ? AppColors.goldLight : AppColors.navy,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              AppConstants.legalDisclaimer,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 11.5,
                height: 1.5,
                color: isDark ? AppColors.darkTextSecondary : AppColors.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
