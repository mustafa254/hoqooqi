import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Bottom sheet opened from the Home screen's "طلب استشارة" quick service.
/// Lets the citizen type a public legal inquiry (max 500 chars) and publish it.
class RequestConsultationSheet extends StatefulWidget {
  final Future<void> Function(String text) onPublish;

  const RequestConsultationSheet({super.key, required this.onPublish});

  static Future<void> show(
    BuildContext context, {
    required Future<void> Function(String text) onPublish,
  }) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => RequestConsultationSheet(onPublish: onPublish),
    );
  }

  @override
  State<RequestConsultationSheet> createState() => _RequestConsultationSheetState();
}

class _RequestConsultationSheetState extends State<RequestConsultationSheet> {
  static const int maxChars = 500;
  final TextEditingController _controller = TextEditingController();
  bool _isPublishing = false;

  int get _count => _controller.text.characters.length;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _publish() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    setState(() => _isPublishing = true);
    try {
      await widget.onPublish(text);
      if (mounted) Navigator.of(context).pop();
    } finally {
      if (mounted) setState(() => _isPublishing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? AppColors.darkSurface : AppColors.surface;

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: BoxDecoration(
          color: bg,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: AppColors.divider,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            Text(
              'طلب استشارة قانونية',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
              textAlign: TextAlign.right,
            ),
            const SizedBox(height: 6),
            Text(
              'اكتب استفسارك القانوني بشكل واضح، وسيتمكن المحامون المهتمون من الرد عليك.',
              style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary, height: 1.5),
              textAlign: TextAlign.right,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _controller,
              maxLength: maxChars,
              maxLines: 6,
              minLines: 4,
              textAlign: TextAlign.right,
              textDirection: TextDirection.rtl,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                hintText: 'مثال: أحتاج استشارة بخصوص عقد إيجار...',
                counterText: '',
              ),
            ),
            const SizedBox(height: 6),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                '$_count/$maxChars',
                style: TextStyle(
                  fontSize: 12,
                  color: _count >= maxChars ? AppColors.danger : AppColors.textSecondary,
                ),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: (_controller.text.trim().isEmpty || _isPublishing) ? null : _publish,
              child: _isPublishing
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Text('نشر الاستشارة'),
            ),
          ],
        ),
      ),
    );
  }
}
